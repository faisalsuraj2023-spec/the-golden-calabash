# THE GOLDEN CALABASH

A React + Vite + TypeScript restaurant ordering frontend connected to Supabase.

## 1. Requirements
- Node.js 20 or newer
- A Supabase project
- The database schema and secure checkout RPC already configured for this project

## 2. Run on your computer
1. Extract this ZIP file.
2. Open the extracted `the-golden-calabash` folder.
3. Create a copy of `.env.example` and name it `.env`.
4. Fill in the Supabase project URL and publishable key. These are available in Supabase project settings.
5. Open a terminal in this folder and run:

   ```bash
   npm install
   npm run dev
   ```

6. Open the local address Vite prints, usually `http://localhost:5173`.

## 3. Upload to GitHub using the website
1. Open your repository: https://github.com/faisalsuraj2023-spec/the-golden-calabash
2. Choose **Add file → Upload files**.
3. Extract this ZIP on your device first.
4. Upload the contents of the extracted folder (including `src`, `package.json`, `index.html`, etc.) into the repository root.
5. Commit the upload to the `main` branch.

Do not upload the ZIP as the only repository file; extract it first so GitHub receives the source files.

## 4. Deploy a preview with Vercel
1. Sign in to Vercel and choose **Add New → Project**.
2. Import `faisalsuraj2023-spec/the-golden-calabash` from GitHub.
3. Framework preset: **Vite**. Build command: `npm run build`. Output directory: `dist`.
4. In Project Settings → Environment Variables, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
5. Deploy. Vercel will provide a preview URL.

## 5. Admin setup
Customers must register normally. Do not make an ordinary customer an administrator.
Have the business owner securely assign the admin role to the intended account in Supabase after confirming the account identity. Never put a service-role key in this frontend or in GitHub.

## 6. Payments
Paystack is not used. Supported checkout methods are bank transfer and cash on delivery.
The bank account details are intentionally not hard-coded. The owner must enter verified business bank details in the restaurant settings before accepting bank-transfer payments. Customers upload transfer proof privately; an administrator verifies it.
Cash-on-delivery payments remain pending until the order is delivered and payment is confirmed.

## 7. Important
This is the frontend source package. Before taking real customer orders, test authentication, RLS, checkout, receipt uploads, admin permissions, and order status transitions in Supabase. Do not treat a successful frontend build as proof that backend security is production-ready.
